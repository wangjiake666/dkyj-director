# 同场分镜

`addon/scene_shots.py` 为一场戏维护一组连续的相机分镜。人物、人物调度、动作关键帧、帧率和场次起止帧都属于原场景；增加或调整分镜只增加相机和帧段，不复制人物，也不会重定时动作。

数据保存在当前 Blender `Scene` 的 `dkyj_shots` JSON 属性里。每一项有稳定 `id`、名称、相机对象名、起止帧和时长。分镜相机统一带有 `dkyj_shot_id` 标记并命名为 `Camera_Shot_<id>`，删除分镜时只会删除自己创建的相机。

## Python 接口

```python
from scene_shots import (
    read_shots, mutate_shots, camera_at_frame,
    bind_shot_markers, validate_sequence,
)

mutate_shots(scene, {
    "action": "add", "name": "出弯侧拍", "duration_seconds": 3.0,
}, current_camera=scene.camera)
mutate_shots(scene, {
    "action": "update", "id": shot_id,
    "duration_seconds": 2.5, "capture": True,
}, current_camera=scene.camera)
mutate_shots(scene, {"action": "delete", "id": shot_id})
```

`add` 默认捕捉当前相机的静态位置、镜头和传感器设置。只有事件明确提供 `source_camera` 时，才复制该相机的动画；这样默认不会覆盖 `Camera_Phone` 或录制机位。`camera_at_frame(scene, frame)` 只读取结果，不切换 `scene.camera`，用于分镜预览或导出器逐帧选择相机。

显式使用 `source_camera` 时，物体和镜头数据的动画曲线会独立复制，并沿用场次原始帧号，不对源动画重定时。使用 `update` 的 `capture: true` 是一次静态快照：会清除该分镜相机已有的动画、父级和约束，再保存当前机位的变换与完整镜头设置。

`bind_shot_markers` 只重建 `DKYJ_SHOT::` 开头的受管标记，保留用户自己的时间线标记。导出前调用 `validate_sequence`；如果相机被手动删除、帧段不连续或超出场次范围，会明确失败，不输出不完整分镜。

目前每场最多 40 个分镜，默认从 `scene.frame_start` 连续排列，不能超过 `scene.frame_end`。多分镜是预览/导出的镜头切换数据，人物调度仍由同一场景的原关键帧驱动。
