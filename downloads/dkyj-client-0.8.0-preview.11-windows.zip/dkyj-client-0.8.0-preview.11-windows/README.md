# DKYJ Director 0.8.0-preview.11

完整客户端 / 免费版与 Pro 功能相同，免费导出右下角带水印，Pro 可免水印。

安装 Blender 5.2 与 Python 3.11–3.14，解压后运行对应系统安装／启动器。Mac 使用 Safari，Windows 使用 Edge；手机使用 iPhone Safari。

升级前保存工程并退出 Blender；迁移 projects/ 与 takes/，不要迁移 .venv/ 或 runtime/。

购买 Pro：https://afdian.com/a/DKYJ666?tab=home
对应源码获取方式见 SOURCE.md；现有许可证保持不变。
