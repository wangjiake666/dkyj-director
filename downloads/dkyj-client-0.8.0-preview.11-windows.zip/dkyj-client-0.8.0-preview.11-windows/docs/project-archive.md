# 项目归档与跨电脑演示

## 验收状态

当前客户端已通过 Safari 完成 9 场工程的导出、导入和再次 API 打包回读，单场景读取验证通过。归档安全检查、HTTP 上传队列和网页语法检查也已通过。

DKYJ Director 的项目归档是一个自包含 ZIP。它保存项目名称、描述、活动场次、每个场次的 Blender 文件和项目目录中的资源，并为每个文件记录 SHA-256。归档不会带入其他项目，也不会带入 `runtime`、`license`、`keys` 或 token 文件。

## 导出

在 Blender 里先对场景执行资源打包（Pack Resources），再运行：

```sh
python scripts/project_archive.py --root . export PROJECT_ID /path/to/demo.dkyj.zip
```

调用者负责在导出前完成 Blender 资源打包；归档工具不启动 Blender，也不修改源项目。

## 导入

```sh
python scripts/project_archive.py --root . import /path/to/demo.dkyj.zip
```

导入总是生成新的项目编号，不覆盖同名或同 ID 的已有项目。免费版与 Pro 均不限制项目中的已保存场次数量，导入保留全部场次，不截断。

导入前会检查 ZIP 路径穿越、符号链接、重复条目、大小限制、manifest 场次数和每个文件的大小及 SHA-256。任何检查失败都会回滚临时目录和项目索引。
