## 2026-10-11 · 可迁移工程包与前七场预演

## 0.8.0-preview.12 · 2026-10-23 · 发布准备

- 默认开启简化人物的前后身份色块：身体前面显示局部胸条，头部下方显示局部色条，背面保留身份色。
- 人物仍由两块可编辑网格组成，不增加四肢；关闭开关可还原纯色。
- 旧场次打开后沿用已有动画和走位，仅补齐可还原的显示样式。
- 本条记录发布准备状态；相关回归、打包和真机检查以本轮实际证据为准，未提前声明通过。

## 0.8.0-preview.11 · 2026-10-13

- 免费版与 Pro 功能统一开放，取消每项目三场次上限与正式项目手柄录制限制。
- 手机、触控、键盘、Xbox / PS5 手柄录制、场内分镜、工程打包及导入均可免费使用。
- 免费导出的视频和图片右下角各带一个 DKYJ Director 水印。合并画面在合成后统一添加，避免重复或错位水印。JSON / TXT 保留导出计划标识。
- Pro 唯一差异为免水印导出。沿用原离线激活方式，已有有效激活码继续使用，无需重新购买。
- 更新授权面板、项目库、GitHub 功能对比与操作说明。

验证：16 项授权、场次、工程归档及水印测试通过；Blender 商业权限回归 9 项通过；手柄合成输入 50 项与手机控制行为检查通过。实际分镜镜头、俯视、空间说明、合并视频均导出并全帧解码，检查了水印位置。Xbox／PS5、iPhone 与 Windows 本轮未进行真机验收。

升级前保存工程并退出 Blender，完整解压新包后运行安装／启动器。迁移 projects/ 与 takes/，不要迁移旧 .venv/、runtime/ 或 addon。Mac 使用 Safari，Windows 使用 Edge；手机使用 iPhone Safari。


## 0.8.0-preview.10 · 2026-10-13

- 无四肢简模新增「正面朝向颜色」开关，用材质标出头部和身体正面，随场次保存。不会增加人物几何或修改走位。未识别的旧详细角色保持原样。
- 手柄移动／升降与转向灵敏度即时读取，兼容 input/change 操作并保存设置。Xbox 为主要映射，PS5 标准映射保留。
- 实时镜头输出目标提高到 24 FPS，网页改为非重叠自适应取图，俯视预览改为 640×360。视频导出仍保持原分辨率和场次帧率；实际预览性能随场景和设备变化。
- 新增「场内分镜」：从当前取景创建机位、设置不同时长、替换角度、连续预览及整场导出。共享人物动画时间轴，切镜头不重置人物动作；超出场次时长或相机被删除会明确报错。
- 分镜支持镜头 16:9、空间 16:9 和双画面参考套件，额外输出分镜时间与机位 JSON。工程打包与导入保留这些设置。

升级前保存工程并退出 Blender；完整解压新客户端并重新运行安装／初始化，迁移 projects/ 与 takes/，不要覆盖迁移 .venv/、runtime/ 或旧 addon。Mac 使用 Safari，Windows 使用 Edge；手机仅支持 iPhone Safari。

验证：Blender 5.2.1 的分镜、材质朝向开关、保存重开、人物动画不变与录制回归；真实短片导出与完整解码。手柄请求使用合成输入验证；本轮未进行 Xbox／PS5、iPhone 或 Windows 真机验收。


- 项目库新增“打包工程”和“导入工程”，保留模型、人物动画、摄影机轨迹、分区和场次描述；导入创建新项目。
- 打包前保存并内嵌 Blender 资源；导入前保存活动场次。临时场次需先保存或放弃。归档检查路径、大小与 SHA-256，不包含许可证和运行令牌。
- 良渚前七场预演改为人物动作带动的连续摄影机运动；保留原手工机位。导出独立16:9镜头画面和机位总览。
- 文件往返、失败回滚与上传接口检查通过；跨电脑实机演示仍需试用。本次仅本地更新。

## 2026-09-21 · Pro 购买入口

- 授权面板“购买 Pro · 爱发电”打开作者指定主页，提示选择 Pro 商品、取得激活码后返回离线激活。购买支付与发码由爱发电商品配置负责。

## 2026-09-21 · Mac 导出启动修复与手柄速度

- 用户 MacBook 日志显示 Blender 在 Python init_sys_streams 阶段报 Bad file descriptor，尚未渲染。导出子进程现在显式连接 DEVNULL 标准输入、日志输出并关闭其他句柄；空间合成子进程同样隔离输入。
- 导出失败显示日志中的具体错误与日志文件名，方便定位。
- 手柄新增独立移动/升降与转向灵敏度（10%–100%，默认 50%），本浏览器保存；保留模拟摇杆力度。
- 11 项录制回归、46 项手柄输入检查与移动/升降/转向缩放检查通过。MacBook 原故障需在该设备复测；本机启动测试未重现其崩溃。

## 2026-09-16 · 固定白模与单描述建模

- 默认固定球头＋长方体身体，两块纯色网格，不含四肢和人物细节；增加标准人物生成 MCP 工具与完成检查。
- 欢迎页合并成一个描述框，直接“开始建模”；旧草稿合并，新任务不会继承详细模式。
- 仅显式详细开关放开细节；普通描述不再触发额外确认。任务仍由连接的 Agent 执行。
- 本次仅更新本地源码和测试包，未上传 GitHub。

## 2026-09-16 · Capture session / 本地候选测试版

- 固定运镜机位，重复录制复用当前轨迹；保留旧用户相机和历史 Take。
- 分离手机与手柄输入，增加执行回执和重试去重；修复共享 Action 重复清理。
- 手机独立横屏双摇杆，常用按钮精简，低频操作折叠；Safari 全屏能力不足时保留可用触控。
- 导出使用已录轨迹快照，文件名防同秒覆盖；修复空间路径末帧时间。
- 已做隔离回归与真实三种导出验证，详情见 [验证记录](docs/fixes/capture-session.md)。本次未上传 GitHub。

# Changelog

## Unreleased — 2026-09-14

- Default scene and character modeling to simple blockout; expose an explicit detailed mode in the welcome brief.
- Persist mode choices and require confirmation before Agent project work when the description requests unconfirmed detail.
- Pass camera-clearance, animation and inspection requirements to the Agent. Preserve original projects.
- Local only; existing models are not automatically decimated.

## 0.8.0-preview.3 — Public download preview, 2026-09-12

- Keep the existing GitHub repository name and URL; the current tree becomes a bilingual download and documentation hub.
- Publish shared Lite/Pro macOS and Windows source-and-launcher bundles with the production v1 verification key and SHA-256 manifests.
- Include Xbox / PS5 profiles, elevation and pitch, three saved Lite scenes per project, Pro controller recording, Preview export watermarks and camera-deletion recovery.
- Keep the room and steamship examples, phone pairing, Blender/MCP onboarding and separate or combined 16:9 views.
- Preserve corresponding GPL application source in each bundle; seller tools, credentials, stock and personal projects stay out of public distribution.
- Afdian automatic purchase/delivery, native Windows GPU, iPhone and PS5 hardware acceptance remain pending.

## 0.8.0-preview.2 — Local production activation readiness

- Embed the author-approved production v1 public key; signed Pro codes now activate offline.
- Preserve preview.1 packages and rebuild both platforms with the same verifier key.
- Verify 10 issued codes, fresh-process restart, wrong-code preservation and rejection of unrelated signing keys.
- Make client-package licensing tests independent of excluded developer issuer tools.
- Afdian purchase/delivery and GitHub publication are still pending.


## 0.8.0-preview.1 — Local build, 2026-09-12

- Lite and Pro now share one macOS/Windows source-and-launcher package. The production Pro key/product are intentionally unconfigured pending owner setup and real delivery acceptance.
- Added strict Ed25519 offline license validation, per-user atomic storage, masked license status, secure activation transport and a compact version panel. The developer issuer stays outside user packages.
- Added project-owned scenes: Lite saves three, excess scenes remain temporary until a user manually deletes a saved scene. Existing projects migrate with an index backup; deletion retains a trash copy. Removed Scene wrappers no longer break the new catalog.
- Kept gamepad camera preview free; Pro gates gamepad recording. Manual recording remains available with Preview watermarks. Added controller ownership, neutral shutdown and heartbeat expiry without changing joystick mathematics.
- Added an isolated built-in demo process for controller trial recording. Formal project writes and demo export are denied.
- Applied Preview marking to POV, overview, board, combined video, stills and reference metadata. Real Blender short exports passed all three modes, including noninteger FPS and Pro passthrough.
- Added CLI/MCP scene commands that wait for the backend project event, and updated source-availability and dependency notices.
- This is a local development build. Real Afdian purchase/delivery, production activation, Windows/iPhone and DualSense hardware acceptance are not complete. Repository privacy/download-site migration has not run.

## Controller development baseline (previously unreleased)

- Added Xbox Series X|S controller camera control to the web viewfinder: left stick movement, right stick turn/pitch, LT/RT elevation and LB/RB focal length.
- Added the four screen controls for elevation and pitch, the waiting/ready/active connection states and the world-coordinate camera Z display. Recording remains on the existing web buttons; controller A/B are not part of this version.
- Added focus-loss, background-pause and disconnect/reconnect centering behavior, with same-page arbitration against phone orientation, keyboard, dragging and screen controls. This baseline originally had no backend lock; 0.8 adds controller ownership and expiry.
- Passed 45 production `web/gamepad.js` and `app.js` behavior checks with at most one concurrent control request. Synthetic input using the production mapping recorded and replayed a 41-frame, 1.708-second Take in Blender 5.2.1 LTS, including elevation, position, pitch and focal length, and produced a 1280×720 MP4.
- Fixed timeline `frame_set` restoring old focal-length keyframes over live zoom during recording; live zoom now enters the Take. Previous Mac Safari 18.6 hardware probing read both sticks and LT/RT/LB/RB; this version's hardware recording in Blender, Windows Edge and iPhone Safari remain unverified.
- See [Xbox / PS5 controller camera control](docs/gamepad.md).
- Added a compact Xbox / PS5 profile selector beside the controller button. Xbox remains the default; the selected value is stored in the browser and invalid values fall back to Xbox.
- Added PS5 standard-layout mapping: L2/R2 for lowering/raising and L1/R1 for focal length. Only `mapping: "standard"` is accepted; PS5 hardware has not been tested; the touchpad, face buttons and vibration are not used.
- Switching profiles pauses the current controller, sends zero input, resets centering protection and requires clicking controller enable again. Production tests cover profile memory, fallback, PS5 mapping, labels, non-standard rejection and re-centering; no PS5 hardware is available for real-device verification.

## 0.7.0-preview.5 — 2026-09-09

- Recover the phone camera after externally deleting active takes; interrupt a deleted recording safely without keying another camera.
- Validate Scene/Object identities, discard deleted project caches and rebuild stale overview rigs; make helper cleanup repeatable.
- Release GPU resources before undo/redo/file loading and prevent state-refresh exceptions from terminating the web timer.
- Keep the green export download button on the neutral gray interface.
- Verified in Blender 5.2.1 on macOS: eight deletion regressions, seven overview cleanup cases, native GPU/HTTP recovery including Undo, project reload and recorded-export regressions.
- Reproduction, upgrade instructions and validation limits: [deleted-camera recovery](docs/fixes/deleted-camera-recovery.md).


## 0.7.0-preview.4 — 2026-09-07

- Phone pairing links open the viewfinder directly and select Camera_Phone once per project; legacy iPhone links also select the phone camera.
- Live control copies use Camera_Phone; animated source cameras and recorded takes remain intact.
- Recorded camera motion and export ownership regression checks pass.


## 0.7.0-preview.3 — 2026-09-07

- Added prominent phone-pairing buttons to the desktop header and welcome page, with local QR codes, copyable links and iPhone Safari setup instructions.
- HTTP and HTTPS QR codes are generated locally and require the active pairing token; no external QR service is used.
- Changed interface colors to neutral grayscale while preserving scene, actor and exported video colors.
- Corrected the isolated Windows CI test user-home environment.
- Excluded proxy benchmark addresses and interface broadcast addresses from phone pairing links.


## 0.7.0-preview.2 — 2026-09-06

- First public preview distribution with separate macOS and Windows bundles.
- Includes curated room and steamship demonstration videos, scene generators and bilingual example instructions.
- Uses an explicit file allowlist; local project libraries, recordings, credentials and QA artifacts are excluded.
- Preserves current camera recording, spatial exports, MCP onboarding and project-switching behavior.
- Native Windows GPU and iPhone acceptance checks remain pending as documented.

## 0.7.0-preview.1 — 2026-09-06 · Not published

- Separate macOS and Windows ZIP installation bundles with platform-specific launchers.
- Windows Blender discovery, saved custom executable, virtualenv paths, UTF-8 data and Chinese font support.
- Shared LAN address detection and optional DKYJ_LAN_IP for server and iPhone TLS.
- Windows desktop opens Edge; mobile support remains iPhone Safari only.
- Added Windows guide and platform branch tests; configured three-OS CI. Native Windows GPU/phone validation is pending.

## 0.6.0-preview.4 — 2026-09-06 · Not published

- Added Douyin, WeChat Official Account and email contacts to desktop/mobile welcome and viewfinder Contact menu.
- Updated bilingual README and release package.

## 0.6.0-preview.3 — 2026-09-06 · Not published

- Added first-use Blender/Python download and Blender MCP setup guidance in the welcome screen.
- macOS launcher now explicitly opens Apple Safari; bilingual documentation uses Safari for Mac and iPhone.
- Replaced the portrait logo with a transparent hand-and-eye design.
- Rechecked project persistence, brief replies, camera ownership and export artifacts.
- Added release-check record with actual coverage and pending Safari device validation.
- Refreshed official Seedance references and prepared a clean source distribution.

## 0.6.0-preview.2 — 2026-09-06 · Not published

- Separate 16:9 POV and spatial-board export buttons.
- Labelled spatial board: 1920×1080; clean POV/observer: 1280×720.
- Combined video: 1920×2160, with two undistorted 1920×1080 panels.
- Added hand-drawn transparent DKYJ Director logo to bilingual README.
- Added export artifact validation, format documentation and logo generation record.

## 0.6.0-preview.1 — 2026-09-06 · Not published

- Added branded desktop/mobile welcome and four-step creative conversation.
- Durable task queue, follow-up replies and truthful waiting/working/ready statuses.
- Optional DKYJ stdio MCP tools for external agents; Blender MCP remains the scene editor.
- Added configuration generator, brief persistence tests and trial guide.
- Fixed project submission pending guard when revision is zero.


## 0.5.1 — 2026-09-06

- English-first repository README with a complete Chinese manual.
- Agent onboarding guide, local connection doctor and English macOS launcher.
- Clarified local runtime versus GitHub Pages hosting.
- Added collaboration contact: 826701673@qq.com.


## 0.5.0 — 2026-09-06

- 名称改为 DKYJ Director · 大开眼界导演台。
- 新增网页项目库：保存、自动保存后切换、复用模型创建独立项目、编辑描述。
- 新增本地项目 CLI 与数据接口；重启恢复活动工程。
- 独立存储 Scene 与依赖，修正 Blender 自动重名后的角色和录制摄影机引用。
- 去除开发机固定目录，增加安装入口、可选 MCP、依赖清单、许可证及源码打包脚本。

## 0.4.0 — 2026-09-06

- 蒸汽小船示例：角色出舱、甲板停步、飞机掠过；陈设与关键帧保留。
- 干净桌面总览、分区尺度、带方向的摄影机视锥、轻微跟随观察机位。
- 同步三路视频、JSON、TXT、说明 PNG；摄影机模型轨迹预先烘焙。
- 可选简化人物导出；整理 Seedance 白模参考材料。

## 0.3.0 — 2026-09-06

- 新增空间分区总览及参考套件导出。

## 0.2.0 — 2026-09-06

- 修正导出未绑定录制镜头的问题。
- 停止录制后暂停体感与触控，恢复取景使用独立 Live 机位。

## 0.1.0 — 2026-09-06

- 本地 Blender 网页取景、iPhone 触控和体感转向、人物动作及可编辑关键帧。
