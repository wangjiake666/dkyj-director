Corresponding source / 对应源码

Version: 0.8.0-preview.12
License: GPL-3.0-or-later (see LICENSE).
Download: https://github.com/wangjiake666/dkyj-director/releases/download/v0.8.0-preview.12/DKYJ-0.8.0-preview.12-corresponding-source.zip

The separate source distribution contains build scripts, tests and editable application modules.
